bl_info = {
    "name": "beb.tools",
    "author": "beb.eth",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "Sidebar",
    "description": "Assembles GLB files and Exports them for Mixamo",
    "warning": "",
    "doc_url": "",
    "category": "Automation",
}


import bpy
import os
import sys
import webbrowser

from bpy.props import (StringProperty,
                       PointerProperty,
                       )

from bpy.types import (Panel,
                       Operator,
                       AddonPreferences,
                       PropertyGroup,
                       )


# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------

class MyProperties(PropertyGroup):

    path : StringProperty(
        name="",
        description="Path to Directory",
        default="",
        maxlen=1024,
        subtype='DIR_PATH')

# ------------------------------------------------------------------------
#    Button 1 Class - Assemble
# ------------------------------------------------------------------------

def button_01(context):
    scene = bpy.context.scene
    
    # Clear the Scene
    def deleteAllObjects():
        """
        Deletes all objects in the current scene
        """
        deleteListObjects = ['MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'HAIR', 'POINTCLOUD', 'VOLUME', 'GPENCIL',
                            'ARMATURE', 'LATTICE', 'EMPTY', 'LIGHT', 'LIGHT_PROBE', 'CAMERA', 'SPEAKER']
    
        # Select all objects in the scene to be deleted:
    
        for o in bpy.context.scene.objects:
            for i in deleteListObjects:
                if o.type == i:
                    o.select_set(False)
                else:
                    o.select_set(True)
        bpy.ops.object.delete() # Deletes all selected objects in the scene
    
    deleteAllObjects()
    
    # Location Path
    path_to_obj_dir = os.path.join(bpy.data.scenes["Scene"].my_tool.path)
    
    # List of all files in Path
    file_list = sorted(os.listdir(path_to_obj_dir))
    
    # Filter for files that end in 'glb' (or 'gltf')
    obj_list = [item for item in file_list if item.endswith('.glb')]
    
    # Add Filtered files into Scene
    for item in obj_list:
        path_to_file = os.path.join(path_to_obj_dir, item)
        bpy.ops.import_scene.gltf(filepath = path_to_file)
        
        # Unlink from Armature
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        
    # Delete Unused EMPTY
    for ob in scene.objects:
        if ob.type == 'EMPTY':
            bpy.data.objects.remove(ob)
    
    # Delete Unused ARMATURE
    for ob in scene.objects:
        if ob.type == 'ARMATURE':
            bpy.data.objects.remove(ob)

    # Delete Unused Modifiers    
    for o in scene.objects:
     if o.type == 'MESH':
         for m in o.modifiers:
             if m.type == 'ARMATURE':
                  o.modifiers.remove(m)

class Assemble(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "assemble.clone"
    bl_label = "Assemble"

    def execute(self, context):
        button_01(context)
        return {'FINISHED'}

# ------------------------------------------------------------------------
#    Button 2 Class - Setup Rig
# ------------------------------------------------------------------------

def button_02(context):
    file_path = os.path.join(bpy.data.scenes["Scene"].my_tool.path)+'/rig.blend'
    inner_path = 'Armature'
    object_name = 'beb.tools.armature'
 
    bpy.ops.wm.append(
        filepath=os.path.join(file_path, inner_path, object_name),
        directory=os.path.join(file_path, inner_path),
       filename=object_name
       )
       
    scene = bpy.context.scene
    for ob in scene.objects:
             if ob.type == 'MESH':
                 armt = bpy.data.objects['beb.tools.armature']
                 ob.modifiers.new(name = 'Armature', type = 'ARMATURE')
                 ob.modifiers['Armature'].object = armt
    
class Clone(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "clone.rig"
    bl_label = "Rig"

    def execute(self, context):
        button_02(context)
        return {'FINISHED'}
    
# ------------------------------------------------------------------------
#    Button 3 Class - Export FBX
# ------------------------------------------------------------------------

def button_03(context):
    scene = bpy.context.scene
    
    # Location Path
    file_path = os.path.join(bpy.data.scenes["Scene"].my_tool.path)
    bpy.ops.export_scene.fbx(filepath=file_path+'CloneExportFBX.fbx', axis_forward='-Z', axis_up='Y', path_mode='COPY', embed_textures=True)

class exportfbx(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "export.fbx"
    bl_label = "FBX"

    def execute(self, context):
        button_03(context)
        return {'FINISHED'}
    
# ------------------------------------------------------------------------
#    Button 4 Class - Export OBJ
# ------------------------------------------------------------------------

def button_04(context):
    scene = bpy.context.scene
    
    # Location Path
    file_path = os.path.join(bpy.data.scenes["Scene"].my_tool.path)
    bpy.ops.export_scene.obj(filepath=file_path+'CloneExportOBJ.obj', axis_forward='-Z', axis_up='Y')

class exportobj(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "export.obj"
    bl_label = "OBJ"

    def execute(self, context):
        button_04(context)
        return {'FINISHED'}

# ------------------------------------------------------------------------
#    Button 5 Class - Export GLB
# ------------------------------------------------------------------------
 
def button_05(context):
    scene = bpy.context.scene
    
    # Location Path
    file_path = os.path.join(bpy.data.scenes["Scene"].my_tool.path)
    bpy.ops.export_scene.gltf(filepath=file_path+'CloneExportGLB.glb')

class exportglb(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "export.glb"
    bl_label = "GLB"

    def execute(self, context):
        button_05(context)
        return {'FINISHED'}
    
# ------------------------------------------------------------------------
#    Button 6 Class - URL Mixamo
# ------------------------------------------------------------------------

def button_06(context):

    webbrowser.open('https://www.mixamo.com')
    
class urlbeb(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "url.beb"
    bl_label = "Mixamo"

    def execute(self, context):
        button_06(context)
        return {'FINISHED'}

# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------

class OBJECT_PT_CustomPanel(Panel):
    bl_idname = "OBJECT_PT_my_panel"
    bl_label = "beb.tools (1.0)"
    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "beb.tools"
    bl_context = "objectmode"

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        layout.label(text="Path: Select Folder Location")
        col = layout.column(align=True)
        col.prop(scn.my_tool, "path", text="")
        
        # button 1
        layout.label(text="Assemble: Combines .glb files")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("assemble.clone")
        # button 2
        layout.label(text="Rig: Applies Saved Armature")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("clone.rig")
        # button 3, 4, 5
        layout.label(text="Export as:")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("export.fbx")
        sub = row.row()
        sub.operator("export.obj")
        sub.operator("export.glb")
        # button 6
        layout.label(text="Mixamo: Opens URL")
        row = layout.row()
        row.scale_y = 1.5
        row.operator("url.beb")

        # print the path to the console
        print (scn.my_tool.path)

# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyProperties,
    OBJECT_PT_CustomPanel,
    Assemble,
    Clone,
    exportfbx,
    urlbeb,
    exportglb,
    exportobj
)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_tool = PointerProperty(type=MyProperties)

def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_tool


if __name__ == "__main__":
    register()